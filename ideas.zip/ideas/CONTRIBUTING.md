Try to include as much information as needed to implement the project, and be open to answer questions if necessary. And please try to answer the issue template as correctly as possible.

By doing this you make the job a whole lot easier for us maintaining the initiative, and we can create more cool projects!

Please also read through the [CoC](https://github.com/open-source-ideas/open-source-ideas/blob/master/CODE_OF_CONDUCT.md) before posting your first idea as well.
